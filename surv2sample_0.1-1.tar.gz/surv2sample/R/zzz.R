.First.lib <- function(lib, pkg)
{
	library.dynam("surv2sample", pkg, lib)
}
