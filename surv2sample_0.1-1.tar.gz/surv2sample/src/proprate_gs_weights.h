
void logrank_weight_q(int *y1, int *y2, int *event, double *time, double *q1, double *q2,
	int *n, int normalised, double *weight);

void gehan_weight_q(int *y1, int *y2, int *event, double *time, double *q1, double *q2,
	int *n, int normalised, double *weight);

void g1_weight_q(int *y1, int *y2, int *event, double *time, double *q1, double *q2,
	int *n, int normalised, double *weight);

