
int my_cholesky2(double *matrix, int *n, double *toler);

void my_chsolve2(double *matrix, int *n, double *y);

void my_chinv2(double *matrix, int *n);
