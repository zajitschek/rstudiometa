
double ks_stat_incr(double *dx, int *n);

double ks_stat_cum(double *x, int *n);

double psupw(double x, int kmax);

double psupb(double x, double a, int kmax);
