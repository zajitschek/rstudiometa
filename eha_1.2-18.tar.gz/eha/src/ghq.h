#ifndef GHQ_H
#define GHQ_H

void F77_CALL(ghq)(int *n, double *x, double *w);

#endif
